// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#include <tnt.h>
#include <vector>
#include <deque>
#include <list>
#include <map>
#include <string>
#include <string.h>
#include <iostream>
#include <set>
#include <time.h>
#include <fstream>
#include <ostream>
#include <sstream>
#include <exception>
#include <algorithm>
#include <numeric>
#include <boost/smart_ptr.hpp>
//#include <boost/algorithm/string.hpp>
//#include <boost/thread.hpp>
//#include <boost/thread/condition.hpp>
#include <boost/format.hpp>

#include "setup_plugin_api.h"
